import UIKit
import Foundation

// Varibles
// var str = "Hello, playground"
// str = "Goodbye"

// Multi line Strings
/*
var str = """
Hello \
playground
"""
*/

// Doubles and Booleans
var pi = 3.141
var awesome = true

// String Interpolation
/*
var score = 85
var str = "Your score was \(score)"
var results = "The test results are here: \(str)"
*/

print("Today's data is \(Date()).")

// Constants
let taylor = "swift"

// Type annotations
let str = "Hello, playground"
let album: String = "Reputation"
let year: Int = 1989
let height: Double = 1.78
let taylorRocks: Bool = true



