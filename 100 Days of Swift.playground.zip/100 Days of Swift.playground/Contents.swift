import UIKit

// DAYS 1-12: INTRODUCTION TO SWIFT  ******************************************
// Day 001 - Variables, simple data types, and string interpolation
// Variables
//var str = "Hello, playground"
//str = "Goodbye"

// Strings and integers
var age = 38
var population = 8_000_000

// Multi-line strings
var str1 = """
This goes
over multiple
lines
"""

var str2 = """
This goes \
over multiple \
lines
"""

// Double and Booleans
var pi = 3.141
var awesome = true

// String interpolation
//var score = 85
//var str = "Your score was \(score)"

//var results = "The test results are here: \(str)"

// Constants
let jimmy = "buffet"

// Type annotations
let str = "Hello, Playground"

let album: String = "Barrometer Soup"
let year: Int = 1989
let height: Double = 1.78
let jimmyRocks: Bool = true

// Day 002 - arrays, dictionaries, sets, and enums
// ARRAYS
let john = "John Lennon"
let paul = "Paul McCartney"
let george = "George Harrison"
let ringo = "Ringo Starr"

//let beatles = [john, paul, george, ringo]

//beatles[1]

// SETS
let colors = Set(["red", "green", "blue"])
colors
let colors2 = Set(["red", "green", "blue", "red", "blue"])
colors2

// TUPLES
var name = (first: "Jimmy", last: "Buffet")
name.0
name.first

// ARRAYS VS SETS VS TUPLES
let address = (house: 555, street: "Jimmy Buffet Avenue", city: "Florala")
let set = Set(["aardvark", "astronaut", "azalea"])
let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]

// DICTIONARIES
let heights = [
    "Jimmy Buffet": 1.78,
    "Needtobreathe": 1.73
]

heights["Jimmy Buffet"]

// DICTIONARY DEFAULT VALUES
let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]

favoriteIceCream["Paul"]
favoriteIceCream["Charlotte"]
favoriteIceCream["Charlotte", default: "Unknown"]

// CREATING EMPTY COLLECTIONS
var teams = [String: String]()
teams["Paul"] = "Red"
//var results = [Int]()
var words = Set<String>()
var numbers = Set<Int>()
var scores = Dictionary<String, Int>()
var results = Array<Int>()

// ENUMERATIONS
let result = "failure"
let result2 = "failed"
let result3 = "fail"

enum Result {
    case success
    case failure
}

let result4 = Result.failure

// ENUM ASSOCIATED VALUES
enum Activity {
    case bored
    case running
    case talking
    case singing
}

enum Activity2 {
    case bored
    case running(destination: String)
    case talking(topic: String)
    case singing(volume: Int)
}

let talking = Activity2.talking(topic: "football")

// ENUM RAW VALUES
//enum Planet: Int {
//    case mercury
//    case venus
//    case earth
//    case mars
//}

let earth = Planet(rawValue: 2)

enum Planet: Int {
    case mercury = 1
    case venus
    case earth
    case mars
}

// Day 003 - operators and conditions
// ARITHMETIC OPERATORS
//let firstScore = 12
//let secondScore = 4

//let total = firstScore + secondScore
//let difference = firstScore - secondScore
//
//let product = firstScore * secondScore
//let divided = firstScore / secondScore
//
//let remainder = 13 % secondScore
//
//// OPERATOR OVERLOADING
//let meaningOfLife = 42
//let doubleMeaning = 42 + 42
//
//let fakers = "Fakers gonna "
//let action = fakers + "fake"
//
//let firstHalf = ["John", "Paul"]
//let secondHalf = ["George", "Ringo"]
//let beatles = firstHalf + secondHalf

// COMPOUND OPERATORS
//var score = 95
//score -= 5
//
//var quote = "The rain in Spain falls mainly on the "
//quote += "Spaniards"
//
////COMPARISON OPERATORS
//let firstScore = 6
//let secondScore = 4
//
//firstScore == secondScore
//firstScore != secondScore
//
//firstScore < secondScore
//firstScore >= secondScore
//
//"Jimmy" <= "Buffet"

// CONDITIONS
//let firstCard = 11
//let secondCard = 10
//
//if firstCard + secondCard == 21 {
//    print("Blackjack!")
//}
//
//if firstCard + secondCard == 21 {
//    print("Blackjack!")
//} else {
//    print("Regular cards")
//}

// COMBINING CONDITIONS
let age1 = 12
let age2 = 21

if age1 > 18 && age2 > 18 {
    print("Both are over 18")
}

if age1 > 18 || age2 > 18 {
    print("At least one is over 18")
}

// THE TERNARY OPERATOR
let firstCard = 11
let secondCard = 10
print(firstCard == secondCard ? "Cards are the same" : "Cards are different")

if firstCard == secondCard {
    print("Cards are the same")
} else {
    print("Cards are different")
}

// SWITCH STATEMENT
let weather = "sunny"

switch weather {
case "rain":
    print("Bring an umbrella")
case "snow":
    print("Wrap up warm")
case "sunny":
    print("Wear sunscreen")
default:
    print("Enjoy your day!")
}

switch weather {
case "rain":
    print("Bring an umbrella")
case "snow":
    print("Wrap up warm")
case "sunny":
    print("Wear sunscreen")
    fallthrough
default:
    print("Enjoy you day!")
}

// RANGE OPERATORS
let score = 85

switch score {
case 0..<50:
    print("You failed badly.")
case 50..<85:
    print("You did OK.")
default:
    print("You did great!")
}

// Day 004 - loops, loops, and more loops
// Day 005 - functions, parameters, and errors
// Day 006 - closures part one
// Day 007 - closures part two
// Day 008 - structs, properties, and methods
// Day 009 - access control, static properties, and laziness
// Day 010 - classes and inheritance
// Day 011 - protocols, extensions, and, protocol extensions
// Day 012 - optionals, unwrapping, and typecasting

// DAYS 13-15: CONSOLIDATION I  ******************************************
// Day 013 - swift review, day one
// Day 014 - swift review, day two
// Day 015 - swift review, day three

// DAYS 16-22: STARTING IOS  ******************************************
// Day 016
// Day 017
// Day 018
// Day 019
// Day 020
// Day 021
// Day 022

// DAY 23: CONSOLIDATION II  ******************************************
// Day 023

// DAYS 24-31: WEB VIEWS, USER INPUT, AND AUTO LAYOUT  ******************************************
// Day 024
// Day 025
// Day 026
// Day 027
// Day 028
// Day 029
// Day 030
// Day 031

// DAY 32: CONSOLIDATION III  ******************************************
// Day 032

// DAYS 33-40: CODABLE, BUTTONS, AND GCD  ******************************************
// Day 033
// Day 034
// Day 035
// Day 036
// Day 037
// Day 038
// Day 039
// Day 040

// DAY 41: CONSOLIDATION IV  ******************************************
// Day 041

// DAYS 42-49: A WHOLE NEW WORLD  ******************************************
// Day 042
// Day 043
// Day 044
// Day 045
// Day 046
// Day 047
// Day 048
// Day 049

// DAYS 50-51: CONSOLIDTATION V  ******************************************
// Day 050
// Day 051

// DAYS 52-58: IMAGES AND ANIMATION  ******************************************
// Day 052
// Day 053
// Day 054
// Day 055
// Day 056
// Day 057
// Day 058

// DAYS 59: CONSOLIDATION VI  ******************************************
// Day 059

// DAYS 60-65: MAPS AND BUGS  ******************************************
// Day 060
// Day 061
// Day 062
// Day 063
// Day 064
// Day 065

// DAY 66: CONSOLIDATION VII  ******************************************
// Day 066

// DAYS 67-73: LEVELING UP  ******************************************
// Day 067
// Day 068
// Day 069
// Day 070
// Day 071
// Day 072
// Day 073

// DAY 74: CONSOLIDATION VIII  ******************************************
// Day 074

// DAYS 75-81: BEACONS AND BOMBS  ******************************************
// Day 075
// Day 076
// Day 077
// Day 078
// Day 079
// Day 080
// Day 081

// DAY 82: CONSOLIDATION IX  ******************************************
// Day 082

// DAYS 83-89: MULITPEER AND MOTION  ******************************************
// Day 083
// Day 084
// Day 085
// Day 086
// Day 087
// Day 088
// Day 089

// DAYS 90-91: CONSOLIDATION X  ******************************************
// Day 090
// Day 091

// DAYS 92-98: THE FINAL COUNTDOWN  ******************************************
// Day 092
// Day 093
// Day 094
// Day 095
// Day 096
// Day 097
// Day 098

// DAY 99: CONSOLIDATION XI  ******************************************
// Day 099

// WRAP UP  ******************************************
// Day 100


