import UIKit

// DAYS 1-12: INTRODUCTION TO SWIFT  ******************************************
// Day 001 - Variables, simple data types, and string interpolation
// Variables
//var str = "Hello, playground"
//str = "Goodbye"

// Strings and integers
//var age = 38
//var population = 8_000_000

// Multi-line strings
//var str1 = """
//This goes
//over multiple
//lines
//"""
//
//var str2 = """
//This goes \
//over multiple \
//lines
//"""
//
//// Double and Booleans
//var pi = 3.141
//var awesome = true
//
//// String interpolation
////var score = 85
////var str = "Your score was \(score)"
//
////var results = "The test results are here: \(str)"
//
//// Constants
////let jimmy = "buffet"
//
//// Type annotations
//let str = "Hello, Playground"
//
//let album: String = "Barrometer Soup"
//let year: Int = 1989
//let height: Double = 1.78
//let jimmyRocks: Bool = true
//
//// Day 002 - arrays, dictionaries, sets, and enums
//// ARRAYS
//let john = "John Lennon"
//let paul = "Paul McCartney"
//let george = "George Harrison"
//let ringo = "Ringo Starr"
//
////let beatles = [john, paul, george, ringo]
//
////beatles[1]
//
//// SETS
//let colors = Set(["red", "green", "blue"])
//colors
//let colors2 = Set(["red", "green", "blue", "red", "blue"])
//colors2
//
//// TUPLES
//var name = (first: "Jimmy", last: "Buffet")
//name.0
//name.first

// ARRAYS VS SETS VS TUPLES
//let address = (house: 555, street: "Jimmy Buffet Avenue", city: "Florala")
//let set = Set(["aardvark", "astronaut", "azalea"])
//let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]

// DICTIONARIES
//let heights = [
//    "Jimmy Buffet": 1.78,
//    "Needtobreathe": 1.73
//]
//
//heights["Jimmy Buffet"]
//
//// DICTIONARY DEFAULT VALUES
//let favoriteIceCream = [
//    "Paul": "Chocolate",
//    "Sophie": "Vanilla"
//]
//
//favoriteIceCream["Paul"]
//favoriteIceCream["Charlotte"]
//favoriteIceCream["Charlotte", default: "Unknown"]
//
//// CREATING EMPTY COLLECTIONS
//var teams = [String: String]()
//teams["Paul"] = "Red"
////var results = [Int]()
//var words = Set<String>()
//var numbers = Set<Int>()
//var scores = Dictionary<String, Int>()
//var results = Array<Int>()
//
//// ENUMERATIONS
////let result = "failure"
////let result2 = "failed"
////let result3 = "fail"
//
//enum Result {
//    case success
//    case failure
//}
//
//let result4 = Result.failure
//
//// ENUM ASSOCIATED VALUES
//enum Activity {
//    case bored
//    case running
//    case talking
//    case singing
//}
//
//enum Activity2 {
//    case bored
//    case running(destination: String)
//    case talking(topic: String)
//    case singing(volume: Int)
//}
//
//let talking = Activity2.talking(topic: "football")
//
//// ENUM RAW VALUES
////enum Planet: Int {
////    case mercury
////    case venus
////    case earth
////    case mars
////}
//
//let earth = Planet(rawValue: 2)
//
//enum Planet: Int {
//    case mercury = 1
//    case venus
//    case earth
//    case mars
//}

// Day 003 - operators and conditions
// ARITHMETIC OPERATORS
//let firstScore = 12
//let secondScore = 4

//let total = firstScore + secondScore
//let difference = firstScore - secondScore
//
//let product = firstScore * secondScore
//let divided = firstScore / secondScore
//
//let remainder = 13 % secondScore
//
//// OPERATOR OVERLOADING
//let meaningOfLife = 42
//let doubleMeaning = 42 + 42
//
//let fakers = "Fakers gonna "
//let action = fakers + "fake"
//
//let firstHalf = ["John", "Paul"]
//let secondHalf = ["George", "Ringo"]
//let beatles = firstHalf + secondHalf

// COMPOUND OPERATORS
//var score = 95
//score -= 5
//
//var quote = "The rain in Spain falls mainly on the "
//quote += "Spaniards"
//
////COMPARISON OPERATORS
//let firstScore = 6
//let secondScore = 4
//
//firstScore == secondScore
//firstScore != secondScore
//
//firstScore < secondScore
//firstScore >= secondScore
//
//"Jimmy" <= "Buffet"

// CONDITIONS
//let firstCard = 11
//let secondCard = 10
//
//if firstCard + secondCard == 21 {
//    print("Blackjack!")
//}
//
//if firstCard + secondCard == 21 {
//    print("Blackjack!")
//} else {
//    print("Regular cards")
//}

// COMBINING CONDITIONS
//let age1 = 12
//let age2 = 21
//
//if age1 > 18 && age2 > 18 {
//    print("Both are over 18")
//}
//
//if age1 > 18 || age2 > 18 {
//    print("At least one is over 18")
//}
//
//// THE TERNARY OPERATOR
//let firstCard = 11
//let secondCard = 10
//print(firstCard == secondCard ? "Cards are the same" : "Cards are different")
//
//if firstCard == secondCard {
//    print("Cards are the same")
//} else {
//    print("Cards are different")
//}
//
//// SWITCH STATEMENT
//let weather = "sunny"
//
//switch weather {
//case "rain":
//    print("Bring an umbrella")
//case "snow":
//    print("Wrap up warm")
//case "sunny":
//    print("Wear sunscreen")
//default:
//    print("Enjoy your day!")
//}
//
//switch weather {
//case "rain":
//    print("Bring an umbrella")
//case "snow":
//    print("Wrap up warm")
//case "sunny":
//    print("Wear sunscreen")
//    fallthrough
//default:
//    print("Enjoy you day!")
//}
//
//// RANGE OPERATORS
//let score = 85
//
//switch score {
//case 0..<50:
//    print("You failed badly.")
//case 50..<85:
//    print("You did OK.")
//default:
//    print("You did great!")
//}
//
//// Day 004 - loops, loops, and more loops
//// FOR LOOPS
//let count = 1...10
//
//for number in count {
//    print("Number is \(number)")
//}
//
//let albums = ["Red", "1989", "Reputation"]
//
//for album in albums {
//    print("\(album) is on Apple Music")
//}
//
//print("Players gonna ")
//
//for _ in 1...5 {
//    print("play")
//}

// WHILE LOOPS
//var number = 1

//while number <= 20 {
//    print(number)
//    number += 1
//}

print("Ready or not, here I come!")

// REPEAT LOOPS
//var number = 1
//
//repeat {
//    print(number)
//    number += 1
//} while number <= 20
//
//print("Ready or not, here I come!")
//
//while false {
//    print("This is false")
//}
//
//repeat {
//    print("This is false")
//} while false
//
//// EXITING LOOPS
//var countDown = 10

//while countDown >= 0 {
//    print(countDown)
//    countDown -= 1
//}
//
//print("Blast off!")

//While countDown >= 0 {
//    print(countDown)
//
//    if countDown == 4 {
//        print("I'm bored.  Let's go now!")
//        break
//    }
//
//    countDown -= 1
//
//}

// EXITING MULTIPLE LOOPS
//for i in 1...10 {
//    for j in 1...10 {
//        let product = i * j
//        print("\(i) * \(j) is \(product)")
//    }
//}
//
//outerLoop: for i in 1...10 {
//    for j in 1...10 {
//        let product = i * j
//        print("\(i) * \(j) is \(product)")
//    }
//}
//
//outerLoop: for i in 1...10 {
//    for j in 1...10 {
//        let product = i * j
//        print("\(i) * \(j) is \(product)")
//
//        if product == 50 {
//            print("It's a bullseye!")
//            break outerLoop
//        }
//    }
//}
//
//// SKIPPING ITEMS
//for i in 1...10 {
//    if i % 2 == 1 {
//        continue
//    }
//
//    print(i)
//}
//
//// INFINITE LOOPS
//var counter = 0
//
//while true {
//    print(" ")
//    counter += 1
//
//    if counter == 273 {
//        break
//    }
//}
//
//
//
//
//// Day 005 - functions, parameters, and errors
//// WRITING FUNCTIONS
//func printHelp() {
//    let message = """
//Welcome to MyApp!
//
//Run this app inside a directory of images and
//MyApp will resize them all into thumbnails
//"""
//
//    print(message)
//}

// ACCEPTING PARAMETERS
//func square(number: Int) {
//    print(number * number)
//}
//
//square(number: 8)

// RETURNING VALUES
//func square(number: Int) -> Int {
//    return number * number
//}
//
//let result = square(number: 8)
//print(result)
//
//// PARAMETER LABELS
//func sayHello(to name: String) {
//    print("Hello, \(name)!")
//}
//
//sayHello(to: "Jimmy")
//
//// OMITTING PARAMETER LABELS
//func greet(_ person: String) {
//    print("Hello, \(person)!")
//}
//
//greet("Jimmy")
//
//// DEFAULT PARAMETERS
//func greet(_ person: String, nicely: Bool = true) {
//    if nicely == true {
//        print("Hello, \(person)!")
//    } else {
//        print("Oh no, it's \(person) again...")
//    }
//}
//
//greet("Jimmy")
//greet("Jimmy", nicely: false)
//
//// VARIADIC FUNCTIONS
//func square(numbers: Int...) {
//    for number in numbers {
//        print("\(number) squared is \(number * number)")
//    }
//}
//
//square(numbers: 1, 2, 3, 4, 5)
//
//// WRITING THROWING FUNCTIONS
//enum PasswordError: Error {
//    case obvious
//}
//
//func checkPassword(_ password: String) throws -> Bool {
//    if password == "password" {
//        throw PasswordError.obvious
//    }
//
//    return true
//}
//
//// RUNNING THROWING FUNCTIONS
//do {
//    try checkPassword("password")
//    print("That password is good!")
//} catch {
//    print("You cant't use that password.")
//}
//
//// INOUT PARAMETERS
//func doubleInPlace(number: inout Int) {
//    number *= 2
//}
//
//var myNum = 10
//doubleInPlace(number: &myNum)

// Day 006 - closures part one
// CREATING BASIC CLOSURES
//let driving = {
//    print("I'm driving in my car")
//}
//
//driving()

// ACCEPTING PARAMETERS
//let driving = { (place: String) in
//    print("I'm goin to \(place) in my car")
//}
//
//driving("London")

// RETURNING VALUES
//let drivingWithReturn = { (place: String) -> String in
//    return "I'm goin to \(place) in my car"
//}
//
//let message = drivingWithReturn("London")
//print(message)

// CLOSURES AS PARAMETERS
//let driving = {
//    print("I'm driving in my car")
//}
//
//func travel(action: () -> Void) {
//    print("I'm getting ready to go.")
//    action()
//    print("I arrived!")
//}

//travel(action: driving)

// TRAILING CLOSURE SYNTAX
//travel() {
//    print("I'm driving in my car")
//}
//
//travel {
//    print("I'm driving in my car")
//}

// CLOSURES WITH PARAMETERS
//func travel(action: (String) -> Void) {
//    print("I'm getting ready to go.")
//    action("London")
//    print("I arrived!")
//}
//
//travel { (place: String) in
//    print("I'm goin to \(place) in my car")
//}

// CLOSURES WITH RETURN VALUES
//func travel(action: (String) -> String) {
//    print("I'm getting ready to go.")
//    let description = action("London")
//    print(description)
//    print("I arrived!")
//}
//
//travel { (place: String) -> String in
//    return "I'm goin to \(place) in my car"
//}
//
//// SHORTHAND PARAMETER NAMES
//travel {place -> String in
//    return "I'm going to \(place) in my car"
//}
//
//travel { place in
//    return "I'm going to \(place) in my car"
//}
//
//travel { place in
//    "I'm going to \(place) in my car"
//}
//
//travel {
//    "I'm going to \($0) in my car"
//}

// CLOSURES WITH MULTIPLE PARAMETERS
//func travel(action: (String, Int) -> String) {
//    print("I'm getting ready to go.")
//    let description = action("London", 60)
//    print(description)
//    print("I arrived!")
//}
//
//travel {
//    "I'm going to \($0) at \($1) miles per hour."
//}
    
// RETURNING CLOSURES
//func travel() -> (String) -> Void {
//    return {
//        print("I'm going to \($0)")
//    }
//}
//
//let result = travel()
//result("London")
//
//let result2 = travel()("London")

// CAPTURING VALUES
//func travel() -> (String) -> Void {
//    return {
//        print("I'm going to \($0)")
//    }
//}

//let result = travel()
//result("London")
//
//func travel() -> (String) -> Void {
//    var counter = 1
//
//    return {
//        print("\(counter).  I'm going to \($0)")
//        counter += 1
//    }
//}
//
//result("London")
//result("London")
//result("London")
    
// Day 007 - closures part two
// Day 008 - structs, properties, and methods
// CREATING YOUR OWN STRUCTS
//struct Sport {
//    var name: String
//}
//
//var tennis = Sport(name: "Tennis")
//
//tennis.name = "Lawn tennis"

// COMPUTED PROPERTIES
//struct Sport {
//    var name: String
//    var isOlympicSport: Bool
//
//    var olympicStatus: String {
//        if isOlympicSport {
//            return "\(name) is an Olympic sport"
//        } else {
//            return "\(name) is not an Olympic sport"
//        }
//    }
//}
//
//let chessBoxing = Sport(name: "Chessboxing", isOlympicSport: false)
//print(chessBoxing.olympicStatus)
//
//// PROPERTY OBSERVERS
////struct Progress {
////    var task: String
////    var amount: Int
////}
//
//var progress = Progress(task: "Loading data", amount: 0)
//progress.amount = 30
//progress.amount = 80
//progress.amount = 100
//
//struct Progress {
//    var task: String
//    var amount: Int {
//        didSet {
//            print("\(task) is now \(amount)% complete")
//        }
//    }
//}
//
//// METHODS
//struct City {
//    var population: Int
//
//    func collectTaxes() -> Int {
//        return population * 1000
//    }
//}
//
//let london = City(population: 9_000_000)
//london.collectTaxes()
//
//// MUTATING METHODS
////struct Person {
////    var name: String
////
////    mutating func makeAnonymous() {
////        name = "Anonymous"
////    }
////}
//
////var person = Person(name: "Ed")
////person.makeAnonymous()
//
//// PROPERTIES AND METHODS OF STRINGS
//let string = "Do or do not, there is no try."
//print(string.count)
//print(string.hasPrefix("Do"))
//print(string.uppercased())
//print(string.sorted())
//
//// PROPERTIES AND METHODS OF ARRAYS
//var toys = ["Woody"]
//print(toys.count)
//toys.append("Buzz")
//toys.firstIndex(of: "Buzz")
//print(toys.sorted())
//toys.remove(at: 0)

// Day 009 - access control, static properties, and laziness
// INITIALIZERS
//struct User {
//    var username: String
//}

//var user = User(username: "twostraws")

//struct User {
//    var username: String
//
//    init() {
//        username = "Anonymous"
//        print("Creating a new user!")
//    }
//}
//
//var user = User()
//user.username = "twostraws"

// REFERRING TO THE CURRENT INSTANCE
//struct Person {
//    var name: String
//
//    init(name: String) {
//        print("\(name) was born!")
//        self.name = name
//    }
//}

// LAZINESS PROPERTIES
//struct FamilyTree {
//    init() {
//        print("Creating family tree!")
//    }
//}
//
//struct Person {
//    var name: String
//    lazy var familyTree = FamilyTree()
//
//    init(name: String) {
//        self.name = name
//    }
//}
//
//var ed = Person(name: "Ed")
//
//ed.familyTree
//
//// STATIC PROPERTIES AND METHODS
//struct Student {
//    static var classSize = 0
//    var name: String
//
//    init(name: String) {
//        self.name = name
//        Student.classSize += 1
//    }
//}
//
//let rob = Student(name: "Rob")
//let Taylor = Student(name: "Taylor")
//print(Student.classSize)

// ACCESS CONTROL
//struct Person {
//    var id: String
//
//    init(id: String) {
//        self.id = id
//    }
//}

//let joe = Person(id: "12345")
//
//struct Person {
//    private var id: String
//
//    init(id: String) {
//        self.id = id
//    }
//
//    func identify() -> String {
//        return "My social security number is \(id)"
//    }
//}
//
//let mike = Person(id: "1234566")
//print(mike)

// Day 010 - classes and inheritance
// CREATING CLASSES
//class Dog {
//    var name: String
//    var breed: String
//
//    init(name: String, breed: String) {
//        self.name = name
//        self.breed = breed
//    }
//}

//let poppy = Dog(name: "Poppy", breed: "Poodle")

// CLASS INHERITANCE
//class Poodle: Dog {
//    init(name: String) {
//        super.init(name: name, breed: "Poodle")
//    }
//}

// OVERRIDING METHODS
//class Dog {
//    func makeNoise() {
//        print("Woof!")
//    }
//}

//class Poodle: Dog {
//
//}

//let poppy = Poodle()
//poppy.makeNoise()
//
//class Poodle: Dog {
//    override func makeNoise() {
//        print("Yip!")
//    }
//}

//final class Dog {
//    var name: String
//    var breed: String
//    init(name: String, breed: String) {
//
//        self.name = name
//
//        self.breed = breed
//
//    }

// COPYING OBJECTS
//class Singer {
//    var name = "Jimmy Buffet"
//}
//
//var singer = Singer()
//print(singer.name)
//
//var singerCopy = singer
//singerCopy.name = "Jeremy Camp"
//
//print(singer.name)

// DEINITIALIZERS
//class Person {
//    var name = "John Doe"
//
//    init() {
//        print("\(name) is alive!")
//    }
//
//    func printGreeting() {
//        print("Hello, I'm \(name)")
//    }
//
//    deinit {
//        print("\(name) is no more!")
//    }
//}
//
//for _ in 1...3 {
//    let person = Person()
//    person.printGreeting()
//}
//
////deinit {
////    print("\(name) is no more!")
////}
//
//// MUTABILITY
//class Singer {
//    var name = "Jimmy Buffet"
//}
//
//let jimmy = Singer()
//jimmy.name = "Creed"
//print(jimmy.name)
    
// Day 011 - protocols, extensions, and, protocol extensions
// PROTOCOLS
//protocol Identifiable {
//    var id: String { get set }
//}
//
//struct User: Identifiable {
//    var id: String
//}
//
//func displayID(thing: Identifiable) {
//    print("My ID is \(thing.id)")
//}

// PROTOCOL INHERITANCE
//protocol Playable {
//    func calculateWates() -> Int
//}
//
//protocol NeedsTraining {
//    func study()
//}
//
//protocol HasVacation {
//    func takeVacation(days: Int)
//}
//
//protocol Employee: Playable, NeedsTraining, HasVacation { }
//
//// EXTENSIONS
//extension Int {
//    func squared() -> Int {
//        return self * self
//    }
//}
//
//let number = 8
//number.squared()
//
//extension Int {
//    var isEven: Bool {
//        return self % 2 == 0
//    }
//}
//
//// PROTOCOL EXTENSIONS
//let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]
//let beatles = Set(["John", "Paul", "George", "Ringo"])
//
//extension Collection {
//    func summarize() {
//        print("There are \(count) of us:")
//
//        for name in self {
//            print(name)
//        }
//    }
//}

//pythons.summarize()
//beatles.summarize()

// PROTOCOL-ORIENTED PROGRAMMING
//protocol Identifiable {
//    var id: String { get set }
//    func identify()
//}
//
//extension Identifiable {
//    func identify() {
//        print("My ID is \(id).")
//    }
//}
//
//struct User: Identifiable {
//    var id: String
//}
//
//let twostraws = User(id: "twostraws")
//twostraws.identify()



// Day 012 - optionals, unwrapping, and typecasting
// HANDLING MISSING DATA
//var age: Int? = nil
//age = 50

// UNWRAPPING OPTIONALS
//var name: String? = nil
//
//if let unwrapped = name {
//    print("\(unwrapped.count) letters")
//} else {
//    print("Missing name.")
//}

// UNWRAPPING WITH GUARD
func greet(_ name: String?) {
    guard let unwrapped = name else {
        print("You didn't provide a name!")
        return
    }
    
    print("Hello, \(unwrapped)!")
}

greet("Rob")

// FORCE UNWRAPPING
//let str = "5"
//let num = Int(str)

//let num = Int(str)!

// IMPLICITLY UNWRAPPED OPTIONALS
let age: Int! = nil

// NIL COALESCIING
func username(for id: Int) -> String? {
    if id == 1 {
        return "Rob Foley"
    } else {
        return nil
    }
}

username(for: 1)

// OPTIONAL CHAINING
let names = ["John", "Paul", "George", "Ringo"]

let beatle = names.first?.uppercased()

// OPTIONAL TRY
enum PasswordError: Error {
    case obvious
}

func checkPassword(_ password: String) throws -> Bool {
    if password == "password" {
        throw PasswordError.obvious
    }
    
    return true
}

do {
    try checkPassword("password")
    print("That password is good!")
} catch {
    print("You can't use that password.")
}

if let result = try? checkPassword("password") {
    print("Result was \(result)")
} else {
    print("D'oh.")
}

try! checkPassword("sekrit")
print("OK!")

// FAILABLE INITIALIZERS
let str = "5"

struct Person {
    var id: String
    
    init?(id: String) {
        if id.count == 9 {
            self.id = id
        } else {
            return nil
        }
    }
}

// TYPECASTING
class Animal { }
class Fish: Animal { }

class Dog: Animal {
    func makeNoise() {
        print("Woof!")
    }
}

let pets = [Fish(), Dog(), Fish(), Dog()]

for pet in pets {
    if let dog = pet as? Dog {
        dog.makeNoise()
    }
}






// DAYS 13-15: CONSOLIDATION I  ******************************************
// Day 013 - swift review, day one
// Day 014 - swift review, day two
// Day 015 - swift review, day three

// DAYS 16-22: STARTING IOS  ******************************************
// Day 016
// Day 017
// Day 018
// Day 019
// Day 020
// Day 021
// Day 022

// DAY 23: CONSOLIDATION II  ******************************************
// Day 023

// DAYS 24-31: WEB VIEWS, USER INPUT, AND AUTO LAYOUT  ******************************************
// Day 024
// Day 025
// Day 026
// Day 027
// Day 028
// Day 029
// Day 030
// Day 031

// DAY 32: CONSOLIDATION III  ******************************************
// Day 032

// DAYS 33-40: CODABLE, BUTTONS, AND GCD  ******************************************
// Day 033
// Day 034
// Day 035
// Day 036
// Day 037
// Day 038
// Day 039
// Day 040

// DAY 41: CONSOLIDATION IV  ******************************************
// Day 041

// DAYS 42-49: A WHOLE NEW WORLD  ******************************************
// Day 042
// Day 043
// Day 044
// Day 045
// Day 046
// Day 047
// Day 048
// Day 049

// DAYS 50-51: CONSOLIDTATION V  ******************************************
// Day 050
// Day 051

// DAYS 52-58: IMAGES AND ANIMATION  ******************************************
// Day 052
// Day 053
// Day 054
// Day 055
// Day 056
// Day 057
// Day 058

// DAYS 59: CONSOLIDATION VI  ******************************************
// Day 059

// DAYS 60-65: MAPS AND BUGS  ******************************************
// Day 060
// Day 061
// Day 062
// Day 063
// Day 064
// Day 065

// DAY 66: CONSOLIDATION VII  ******************************************
// Day 066

// DAYS 67-73: LEVELING UP  ******************************************
// Day 067
// Day 068
// Day 069
// Day 070
// Day 071
// Day 072
// Day 073

// DAY 74: CONSOLIDATION VIII  ******************************************
// Day 074

// DAYS 75-81: BEACONS AND BOMBS  ******************************************
// Day 075
// Day 076
// Day 077
// Day 078
// Day 079
// Day 080
// Day 081

// DAY 82: CONSOLIDATION IX  ******************************************
// Day 082

// DAYS 83-89: MULITPEER AND MOTION  ******************************************
// Day 083
// Day 084
// Day 085
// Day 086
// Day 087
// Day 088
// Day 089

// DAYS 90-91: CONSOLIDATION X  ******************************************
// Day 090
// Day 091

// DAYS 92-98: THE FINAL COUNTDOWN  ******************************************
// Day 092
// Day 093
// Day 094
// Day 095
// Day 096
// Day 097
// Day 098

// DAY 99: CONSOLIDATION XI  ******************************************
// Day 099

// WRAP UP  ******************************************
// Day 100


