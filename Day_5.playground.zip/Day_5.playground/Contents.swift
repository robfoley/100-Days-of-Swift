import UIKit

// Writing functions
/*
func printHelp() {
    let message = """
Welcome to MyApp!

Run this app inside a directory of images and MyApp will resize them all into thumbnails
"""
    
    print(message)
}

printHelp()
*/

// Accepting parameters
/*
func square(number: Int) {
    print(number * number)
}

square(number: 8)
*/

// Returning values
/*
func square(number: Int) -> Int {
    return number * number
}

let result = square(number: 8)
print(result)
*/

// Parameter labels




// Omitting parameter labels

// Default parameters

// Variadic functions

// Writing throwing functions

// inout parameters


